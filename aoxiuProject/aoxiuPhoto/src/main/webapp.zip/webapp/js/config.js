module.exports = {
    'ACCESS_KEY': 'wYxSvi8xm9d42z7NvbUai3jzw_G94fOpt_9jrE3m', // <Your Access Key>
    'SECRET_KEY': 'mtPIx43Hl8zhEPXo3Fl2aNPd4TUFZIknbuRPHFOJ', // <Your Secret Key>
    'Bucket_Name': 'xuanpianer', // <Your Bucket Name>
    'Port': 19110,
    'Uptoken_Url': '/uptoken',
    'Domain': 'http://qiniu-plupload.qiniudn.com/'
};
