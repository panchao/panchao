// public helper mount in window.legend.helper
window.legend = {
  helper: {}
};
