/*
 * 上传图片
 */
var qiniu = require('qiniu');
var express = require('express');
var config = require('./config');
var app = express();

app.configure(function() {
    app.use(express.static(__dirname + '/'));
});
app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);
app.use(express.urlencoded());

app.listen(config.port, function() {
    console.log('Listening on port %d', config.port);
});

app.get('/', function(req, res) {
    res.render('photo_new_order.ftl', { //  index
        domain: config.Domain,
        uptoken_url: config.Uptoken_Url
    });
});
app.get('../query/getPhotographerUsers', function (req, res) {
    res.json([{"customerId":0,"realName":"xiaoming","phoneNumber":"18501038260","email":null,"photographersId":1,"weChat":"1234567","qqnumber":"1234567"},{"customerId":0,"realName":"222","phoneNumber":"222","email":"222","photographersId":1,"weChat":"22","qqnumber":"222"}]);
});
app.post('../order/addOrder.do', function (req, res) {
  res.json(req.body);
})

// 上传图片
app.get('/uptoken', function(req, res, next) {
    var token = uptoken.token();

    res.header("Cache-Control", "max-age=0, private, must-revalidate");
    res.header("Pragma", "no-cache");
    res.header("Expires", 0);
    if (token) {
        res.json({
            uptoken: token
        });
    }
});

app.post('/uploadfiles', function (req, res) {
    res.json({
      username: req.body.username,
      files: req.body.files
    })
});

qiniu.conf.ACCESS_KEY = config.ACCESS_KEY;
qiniu.conf.SECRET_KEY = config.SECRET_KEY;

var uptoken = new qiniu.rs.PutPolicy(config.Bucket_Name);

app.post('/album', function (req, res) {
    //console.log(req.body);
    res.json({
      album_id: 123456
    })
});

app.get('/album/:photograper_id/:album_id', function (req, res) {
    console.log(req.params);
    res.send('hello');
  /*res.json({
    albums: [{
      name: 'album_name#1',
      id: 0
    }, {
      name: 'album_name#2',
      id: 1
    }], 
    photos: [{
      name: 'lizard-girl.jpg',
      src: 'http://qiniu-plupload.qiniudn.com/lizard-girl.jpg?imageView2/1/w/100/h/100'
    }, {
      name: 'lizard-girl2.jpg',
      src: 'http://qiniu-plupload.qiniudn.com/lizard-girl.jpg?imageView2/1/w/100/h/100'
    }]
  });*/
});
